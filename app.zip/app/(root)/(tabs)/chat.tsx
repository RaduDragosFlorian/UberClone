import React, { useState, useEffect } from "react";
import {
  View,
  TextInput,
  Button,
  Text,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
} from "react-native";
import { useUser } from "@clerk/clerk-expo";

import Constants from "expo-constants";
import { fetchAPI } from "@/lib/fetch";

const API_URL = Constants?.expoConfig?.extra?.apiUrl || "https://uber.dev/";
const buildPath = (path: string) =>
  `${API_URL.replace(/\/$/, "")}/${path.replace(/^\//, "")}`;

type User = { id: number; name: string; email: string };
type Message = {
  id: number;
  sender_id: number;
  receiver_id: number;
  content: string;
  created_at: string;
};

const ChatScreen = () => {
  const { user: clerkUser } = useUser();
  const [email, setEmail] = useState("");
  const [foundUser, setFoundUser] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [searching, setSearching] = useState(false);
  const [sending, setSending] = useState(false);

  // Replace with actual user id fetched from your backend
  const currentUserId = 1;

  const searchUser = async () => {
    if (!email.trim()) return;
    setSearching(true);
    try {
      const result = await fetchAPI(
        buildPath(`/api/users/search?email=${encodeURIComponent(email)}`),
      );
      if (result.error) throw new Error(result.error);
      setFoundUser(result.data);
      setMessages([]);
      setNewMessage("");
    } catch (err: any) {
      Alert.alert("Error", err.message);
      setFoundUser(null);
    } finally {
      setSearching(false);
    }
  };

  useEffect(() => {
    if (!foundUser) return;
    (async () => {
      try {
        const history = await fetchAPI(
          buildPath(`/api/messages/${foundUser.id}`),
        );
        if (history.error) throw new Error(history.error);
        setMessages(history.data);
      } catch (err: any) {
        Alert.alert("Error loading messages", err.message);
      }
    })();
  }, [foundUser]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !foundUser) return;
    setSending(true);
    try {
      const result = await fetchAPI(buildPath("/api/messages"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: currentUserId,
          receiverId: foundUser.id,
          content: newMessage,
        }),
      });
      if (result.error) throw new Error(result.error);

      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          sender_id: currentUserId,
          receiver_id: foundUser.id,
          content: newMessage,
          created_at: new Date().toISOString(),
        },
      ]);
      setNewMessage("");
    } catch (err: any) {
      Alert.alert("Error sending message", err.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={90}
    >
      <View style={styles.inner}>
        <Text style={styles.title}>Chat</Text>

        <View style={styles.searchContainer}>
          <TextInput
            style={styles.input}
            placeholder="Search by email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
          />
          <Button title={searching ? "…" : "Go"} onPress={searchUser} />
        </View>

        {foundUser && (
          <>
            <Text style={styles.subtitle}>
              Chatting with {foundUser.name} ({foundUser.email})
            </Text>

            <FlatList
              style={styles.list}
              data={messages}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <View
                  style={[
                    styles.messageBubble,
                    item.sender_id === currentUserId
                      ? styles.sent
                      : styles.received,
                  ]}
                >
                  <Text
                    style={
                      item.sender_id === currentUserId
                        ? styles.sentText
                        : styles.receivedText
                    }
                  >
                    {item.content}
                  </Text>
                </View>
              )}
            />

            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                placeholder="Type a message…"
                value={newMessage}
                onChangeText={setNewMessage}
              />
              <Button title={sending ? "…" : "Send"} onPress={sendMessage} />
            </View>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  inner: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
  },
  subtitle: {
    marginBottom: 8,
    fontWeight: "600",
  },
  searchContainer: {
    flexDirection: "row",
    marginBottom: 16,
    alignItems: "center",
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
  },
  list: {
    flex: 1,
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  messageBubble: {
    padding: 10,
    borderRadius: 8,
    maxWidth: "75%",
    marginVertical: 4,
  },
  sent: {
    alignSelf: "flex-end",
    backgroundColor: "#2563EB",
  },
  received: {
    alignSelf: "flex-start",
    backgroundColor: "#E5E7EB",
  },
  sentText: {
    color: "#fff",
  },
  receivedText: {
    color: "#000",
  },
});

export default ChatScreen;
