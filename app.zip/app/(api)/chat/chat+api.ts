// app/api/messages/route.ts
import { neon } from "@neondatabase/serverless";

export async function POST(request: Request) {
  const { senderId, receiverId, content } = await request.json();
  if (!senderId || !receiverId || !content) {
    return Response.json({ error: "Missing required fields" }, { status: 400 });
  }

  try {
    const sql = neon(process.env.DATABASE_URL!);
    await sql`
      INSERT INTO messages (sender_id, receiver_id, content)
      VALUES (${senderId}, ${receiverId}, ${content})
    `;
    return Response.json({ success: true });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
