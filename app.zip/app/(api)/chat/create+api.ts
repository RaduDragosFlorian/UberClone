// app/api/users/search/route.ts
import { neon } from "@neondatabase/serverless";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const email = searchParams.get("email");
  if (!email) {
    return Response.json({ error: "Email is required" }, { status: 400 });
  }

  try {
    const sql = neon(process.env.DATABASE_URL!);
    const users =
      await sql`SELECT id, name, email FROM users WHERE email = ${email}`;
    if (users.length === 0) {
      return Response.json({ error: "User not found" }, { status: 404 });
    }
    return Response.json({ data: users[0] });
  } catch (err) {
    console.error(err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
